package pojo_EcommerceAPITest;

import java.util.List;

public class Orders {

	private List<OrdersDetails> Orders;

	public List<OrdersDetails> getOrders() {
		return Orders;
	}

	public void setOrder(List<OrdersDetails> orders) {
		Orders = orders;
	}
	
	
}
