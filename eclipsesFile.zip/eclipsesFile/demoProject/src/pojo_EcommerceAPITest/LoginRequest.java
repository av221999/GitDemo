package pojo_EcommerceAPITest;

public class LoginRequest {
   private final String userEmail = "casanova.01@gmail.com";
   private  final String userPassword = "Casanova@1";
   
public String getUserEmail() {
	return userEmail;
}

public String getUserPassword() {
	return userPassword;
}

}
