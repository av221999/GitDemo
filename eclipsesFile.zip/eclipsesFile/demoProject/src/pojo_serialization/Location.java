package pojo_serialization;

public class Location {

	private double lat;
	private double lng;
	
	public double getLat() {
		return lat;
	}
	public void setLat(double d) {
		this.lat = d;
	}
	
	public double getLng() {
		return lng;
	}
	public void setLng(double d) {
		this.lng = d;
	}
	
	
}
